# ChurnLens AI — финальная сборка

## Структура

```
churnlens-final/
├── frontend/
│   └── index.html          # Весь фронтенд, один файл (Tailwind CDN, Chart.js, XLSX)
├── backend/
│   ├── src/                # Express + TypeScript backend
│   ├── supabase/schema.sql # SQL-схема для Supabase
│   ├── package.json
│   ├── tsconfig.json
│   ├── .env.example
│   ├── .gitignore
│   └── README.md           # Подробная инструкция по бэкенду
└── docs/
    ├── security-headers.md       # Конфиги HTTP security headers (Netlify/Vercel/Nginx)
    ├── SECURITY_AUDIT_round1.md
    ├── SECURITY_AUDIT_ROUND2.md
    └── SECURITY_AUDIT_ROUND3.md
```

## Быстрый старт

### 1. Backend

```bash
cd backend
cp .env.example .env   # заполните реальными ключами (Anthropic, Supabase, Stripe, JWT)
npm install
npm run dev             # http://localhost:8080
```

Полная инструкция (Supabase/Google/GitHub/Stripe) — в `backend/README.md`.

### 2. Frontend

Откройте `frontend/index.html` в браузере. По умолчанию он обращается к `/api/*` на том же
origin — если backend на другом домене, поменяйте `API_BASE` в начале `<script>` внутри файла.

### 3. Продакшен

Заголовки безопасности для статического хостинга фронтенда — `docs/security-headers.md`.
История аудитов безопасности — `docs/SECURITY_AUDIT_*.md`.

## Примечание

`backend/src/routes/compare.ts` — эндпоинт `/api/compare-competitor`, вызываемый фронтендом,
был добавлен при сборке финальной версии (раньше существовал только как контракт в
комментариях frontend/index.html, не как реальный роут).
