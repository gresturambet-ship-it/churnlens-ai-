import { Router } from "express";
import { z } from "zod";
import { supabaseAdmin } from "../lib/supabase.js";
import { logger } from "../lib/logger.js";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.js";
import { checkUsageLimit } from "../lib/usageLimit.js";

export const reportsRouter = Router();

reportsRouter.get("/usage", requireAuth, async (req: AuthenticatedRequest, res) => {
  const usage = await checkUsageLimit(req.user!.id, "analyze");
  return res.json(usage);
});

reportsRouter.get("/reports", requireAuth, async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const limit = Math.min(Number(req.query.limit) || 30, 100);

  const { data, error } = await supabaseAdmin
    .from("reports")
    .select("id, summary, sentiment, urgency, churn_forecast, created_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) {
    logger.error({ err: error }, "Failed to list reports");
    return res.status(500).json({ error: "Не удалось загрузить историю" });
  }
  return res.json({ reports: data });
});

reportsRouter.get("/reports/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const { data, error } = await supabaseAdmin
    .from("reports")
    .select("*")
    .eq("id", req.params.id)
    .eq("user_id", userId)
    .single();

  if (error || !data) return res.status(404).json({ error: "Отчёт не найден" });
  return res.json({ report: data });
});

reportsRouter.delete("/reports/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const { error } = await supabaseAdmin
    .from("reports")
    .delete()
    .eq("id", req.params.id)
    .eq("user_id", userId);

  if (error) return res.status(500).json({ error: "Не удалось удалить отчёт" });
  return res.status(204).send();
});

const CompareQuerySchema = z.object({
  period: z.enum(["week", "month"]).default("week")
});

// Compares the most recent report against the average of the prior period.
reportsRouter.get("/reports/compare/summary", requireAuth, async (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const parsed = CompareQuerySchema.safeParse(req.query);
  if (!parsed.success) return res.status(400).json({ error: "Некорректные параметры" });

  const days = parsed.data.period === "week" ? 7 : 30;
  const since = new Date(Date.now() - days * 2 * 24 * 60 * 60 * 1000).toISOString();
  const midpoint = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

  const { data, error } = await supabaseAdmin
    .from("reports")
    .select("id, payload, created_at")
    .eq("user_id", userId)
    .gte("created_at", since)
    .order("created_at", { ascending: false });

  if (error) return res.status(500).json({ error: "Не удалось загрузить данные для сравнения" });
  if (!data || data.length === 0) {
    return res.json({ current: null, previous: null, delta: null, message: "Недостаточно данных за период" });
  }

  const current = data.filter((r) => r.created_at >= midpoint);
  const previous = data.filter((r) => r.created_at < midpoint);

  const avgReasonPercent = (rows: typeof data, label: string) => {
    const values = rows
      .flatMap((r) => (r.payload as { reasons?: { label: string; percent: number }[] }).reasons ?? [])
      .filter((r) => r.label === label)
      .map((r) => r.percent);
    return values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;
  };

  const currentLabels = new Set(
    current.flatMap((r) => (r.payload as { reasons?: { label: string }[] }).reasons?.map((x) => x.label) ?? [])
  );

  const delta = Array.from(currentLabels).map((label) => {
    const curr = avgReasonPercent(current, label);
    const prev = avgReasonPercent(previous, label);
    return { label, current: curr, previous: prev, change: curr !== null && prev !== null ? curr - prev : null };
  });

  return res.json({ currentCount: current.length, previousCount: previous.length, delta });
});
