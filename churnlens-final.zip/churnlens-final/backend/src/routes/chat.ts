import { Router } from "express";
import { z } from "zod";
import { callClaude } from "../lib/claude.js";
import { supabaseAdmin } from "../lib/supabase.js";
import { logger } from "../lib/logger.js";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.js";
import { analysisRateLimiter } from "../middleware/rateLimit.js";
import { RequestWithId } from "../middleware/requestId.js";
import { handleClaudeRouteError } from "../lib/errorHandler.js";
import { CLAUDE_PRESETS } from "../config.js";
import { sanitizePromptInjection } from "../lib/sanitize.js";
import { checkReplay } from "../lib/replayGuard.js";
import { checkUsageLimit } from "../lib/usageLimit.js";

export const chatRouter = Router();

const ChatRequestSchema = z.object({
  reportId: z.string().uuid(),
  question: z.string().min(2).max(2000),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .max(20)
    .default([])
});

chatRouter.post("/chat", requireAuth, analysisRateLimiter, async (req: AuthenticatedRequest, res) => {
  const parsed = ChatRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Некорректный запрос", details: parsed.error.flatten() });
  }

  const { reportId, history } = parsed.data;
  const question = sanitizePromptInjection(parsed.data.question);
  const userId = req.user!.id;
  const requestId = (req as RequestWithId).requestId;

  if (!checkReplay(`${userId}:chat:${reportId}`, question)) {
    return res.status(409).json({ error: "Этот же вопрос уже обрабатывается." });
  }

  const usage = await checkUsageLimit(userId, "chat");
  if (!usage.allowed) {
    return res.status(429).json({
      error: `Лимит чата исчерпан: ${usage.used}/${usage.limit} в этом месяце (тариф ${usage.plan}).`,
      plan: usage.plan,
      used: usage.used,
      limit: usage.limit
    });
  }

  const { data: report, error } = await supabaseAdmin
    .from("reports")
    .select("payload, raw_input_excerpt, user_id")
    .eq("id", reportId)
    .single();

  if (error || !report) return res.status(404).json({ error: "Отчёт не найден" });
  if (report.user_id !== userId) return res.status(403).json({ error: "Нет доступа к этому отчёту" });

  const system = `Ты — retention-консультант. У тебя есть JSON-отчёт по анализу оттока клиентов и выдержка исходных отзывов.
Отвечай на вопросы пользователя ТОЛЬКО на основе этих данных, конкретно и по делу, на русском языке. Если данных недостаточно для ответа — прямо скажи об этом.

ОТЧЁТ:
${JSON.stringify(report.payload)}

ИСХОДНЫЕ ДАННЫЕ (выдержка):
${report.raw_input_excerpt}`;

  try {
    const answer = await callClaude({
      system,
      messages: [...history, { role: "user", content: question }],
      ...CLAUDE_PRESETS.chat,
      requestId
    });
    await supabaseAdmin.from("api_usage").insert({
      user_id: userId,
      endpoint: "chat",
      tokens_estimate: question.length,
      created_at: new Date().toISOString()
    });
    return res.json({ answer });
  } catch (err) {
    handleClaudeRouteError(err, res, "/chat");
  }
});
