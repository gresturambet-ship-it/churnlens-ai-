import { Router } from "express";
import { z } from "zod";
import { callClaude, parseClaudeJson } from "../lib/claude.js";
import { logger } from "../lib/logger.js";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.js";
import { analysisRateLimiter } from "../middleware/rateLimit.js";
import { RequestWithId } from "../middleware/requestId.js";
import { handleClaudeRouteError } from "../lib/errorHandler.js";
import { CLAUDE_PRESETS } from "../config.js";
import { sanitizePromptInjection } from "../lib/sanitize.js";
import { checkUsageLimit } from "../lib/usageLimit.js";
import { supabaseAdmin } from "../lib/supabase.js";

export const compareRouter = Router();

const CompareSchema = z.object({
  report: z.record(z.unknown()),
  competitorText: z.string().min(10).max(50000)
});

const SYSTEM_PROMPT = `Ты — конкурентный аналитик. У тебя есть отчёт по отзывам компании (JSON) и сырые отзывы о конкуренте.
Верни ТОЛЬКО JSON: {"ourStrengths":["...", ...], "ourWeaknesses":["...", ...]}. 3-5 пунктов в каждом, конкретно, на русском.`;

compareRouter.post("/compare-competitor", requireAuth, analysisRateLimiter, async (req: AuthenticatedRequest, res) => {
  const parsed = CompareSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Некорректный запрос", details: parsed.error.flatten() });

  const competitorText = sanitizePromptInjection(parsed.data.competitorText);
  const userId = req.user!.id;

  const usage = await checkUsageLimit(userId, "compare");
  if (!usage.allowed) {
    return res.status(429).json({
      error: `Лимит сравнений исчерпан: ${usage.used}/${usage.limit} в этом месяце (тариф ${usage.plan}).`,
      plan: usage.plan,
      used: usage.used,
      limit: usage.limit
    });
  }

  const system = `${SYSTEM_PROMPT}\n\nОТЧЁТ О НАШЕЙ КОМПАНИИ:\n${JSON.stringify(parsed.data.report)}`;

  try {
    const raw = await callClaude({
      system,
      messages: [{ role: "user", content: competitorText }],
      ...CLAUDE_PRESETS.compare,
      requestId: (req as RequestWithId).requestId
    });
    const result = parseClaudeJson<{ ourStrengths?: string[]; ourWeaknesses?: string[] }>(raw);
    await supabaseAdmin.from("api_usage").insert({
      user_id: userId,
      endpoint: "compare",
      tokens_estimate: competitorText.length,
      created_at: new Date().toISOString()
    });
    return res.json({ ourStrengths: result.ourStrengths ?? [], ourWeaknesses: result.ourWeaknesses ?? [] });
  } catch (err) {
    handleClaudeRouteError(err, res, "/compare-competitor");
  }
});
