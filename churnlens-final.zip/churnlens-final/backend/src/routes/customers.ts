import { Router } from "express";
import { supabaseAdmin } from "../lib/supabase.js";
import { logger } from "../lib/logger.js";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.js";

export const customersRouter = Router();

// Deterministic status thresholds on the existing riskScore (0-100, higher = worse) — same
// mapping style already used elsewhere in this project (e.g. urgency -> risk level), not a
// new invented metric.
function statusFromRisk(riskScore: number | null): string {
  if (riskScore === null) return "Нет данных";
  if (riskScore < 25) return "Healthy";
  if (riskScore < 50) return "Warning";
  if (riskScore < 75) return "At Risk";
  return "Critical";
}

interface ReportRow {
  id: string;
  customer_name: string | null;
  summary: string;
  payload: Record<string, unknown>;
  created_at: string;
}

// GET /api/customers — every distinct customer_name this user has tagged an analysis with,
// with Health Score / Risk / status derived from their most recent analysis only.
customersRouter.get("/customers", requireAuth, async (req: AuthenticatedRequest, res) => {
  const { data, error } = await supabaseAdmin
    .from("reports")
    .select("id, customer_name, summary, payload, created_at")
    .eq("user_id", req.user!.id)
    .not("customer_name", "is", null)
    .order("created_at", { ascending: false });

  if (error) {
    logger.error({ err: error }, "Failed to list customers");
    return res.status(500).json({ error: "Не удалось загрузить список клиентов" });
  }

  const byCustomer = new Map<string, ReportRow[]>();
  for (const row of (data || []) as ReportRow[]) {
    const name = row.customer_name!;
    if (!byCustomer.has(name)) byCustomer.set(name, []);
    byCustomer.get(name)!.push(row);
  }

  const customers = Array.from(byCustomer.entries()).map(([name, rows]) => {
    const latest = rows[0]; // already sorted desc by created_at
    const payload = latest.payload as {
      aiScore?: number;
      riskScore?: number;
      topRisks?: { label?: string }[];
      reasons?: { label?: string }[];
    };
    const riskReason = payload.topRisks?.[0]?.label || payload.reasons?.[0]?.label || null;
    return {
      name,
      healthScore: typeof payload.aiScore === "number" ? payload.aiScore : null,
      churnRisk: typeof payload.riskScore === "number" ? payload.riskScore : null,
      riskReason,
      status: statusFromRisk(typeof payload.riskScore === "number" ? payload.riskScore : null),
      lastActivity: latest.created_at,
      analysesCount: rows.length
    };
  });

  return res.json({ customers });
});

// GET /api/customers/:name — profile: every analysis tagged with this customer name, plus
// the latest report's reasons/quickWins as "risk causes" / "AI recommendations" (real data
// already computed, nothing new invented for this endpoint).
customersRouter.get("/customers/:name", requireAuth, async (req: AuthenticatedRequest, res) => {
  const name = req.params.name;
  const { data, error } = await supabaseAdmin
    .from("reports")
    .select("id, customer_name, summary, payload, created_at")
    .eq("user_id", req.user!.id)
    .eq("customer_name", name)
    .order("created_at", { ascending: false });

  if (error) {
    logger.error({ err: error }, "Failed to load customer profile");
    return res.status(500).json({ error: "Не удалось загрузить профиль клиента" });
  }
  if (!data || data.length === 0) {
    return res.status(404).json({ error: "Клиент не найден" });
  }

  const rows = data as ReportRow[];
  const latestPayload = rows[0].payload as {
    aiScore?: number;
    riskScore?: number;
    topRisks?: unknown[];
    reasons?: unknown[];
    quickWins?: string[];
  };

  return res.json({
    name,
    healthScore: typeof latestPayload.aiScore === "number" ? latestPayload.aiScore : null,
    churnRisk: typeof latestPayload.riskScore === "number" ? latestPayload.riskScore : null,
    status: statusFromRisk(typeof latestPayload.riskScore === "number" ? latestPayload.riskScore : null),
    riskCauses: latestPayload.topRisks?.length ? latestPayload.topRisks : (latestPayload.reasons || []),
    recommendations: latestPayload.quickWins || [],
    analyses: rows.map((r) => ({ id: r.id, summary: r.summary, createdAt: r.created_at }))
  });
});
