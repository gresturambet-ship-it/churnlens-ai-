import { Router } from "express";
import Stripe from "stripe";
import { z } from "zod";
import { env } from "../env.js";
import { supabaseAdmin } from "../lib/supabase.js";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.js";
import { logger } from "../lib/logger.js";

export const stripeRouter = Router();
const stripe = new Stripe(env.STRIPE_SECRET_KEY);

const PLAN_PRICE_MAP: Record<string, string> = {
  pro: env.STRIPE_PRICE_PRO,
  business: env.STRIPE_PRICE_BUSINESS
};

const CheckoutSchema = z.object({ plan: z.enum(["pro", "business"]) });

stripeRouter.post("/billing/checkout", requireAuth, async (req: AuthenticatedRequest, res) => {
  const parsed = CheckoutSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Некорректный план" });

  const priceId = PLAN_PRICE_MAP[parsed.data.plan];
  const userId = req.user!.id;
  const userEmail = req.user!.email;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer_email: userEmail,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${env.CLIENT_ORIGIN}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${env.CLIENT_ORIGIN}/pricing`,
      client_reference_id: userId,
      metadata: { userId, plan: parsed.data.plan }
    });
    return res.json({ url: session.url });
  } catch (err) {
    logger.error({ err }, "Stripe checkout session creation failed");
    return res.status(502).json({ error: "Не удалось создать сессию оплаты" });
  }
});

// IMPORTANT: this route must receive the RAW request body, not JSON-parsed.
// Mount it with express.raw({ type: "application/json" }) in index.ts BEFORE express.json().
stripeRouter.post("/billing/webhook", async (req, res) => {
  const signature = req.headers["stripe-signature"];
  if (!signature) return res.status(400).send("Missing Stripe signature");

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    logger.error({ err }, "Stripe webhook signature verification failed");
    return res.status(400).send("Invalid signature");
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.client_reference_id;
        const plan = session.metadata?.plan ?? "pro";
        if (userId) {
          await supabaseAdmin
            .from("subscriptions")
            .upsert(
              {
                user_id: userId,
                stripe_customer_id: session.customer as string,
                stripe_subscription_id: session.subscription as string,
                plan,
                status: "active",
                updated_at: new Date().toISOString()
              },
              { onConflict: "user_id" }
            );
          await supabaseAdmin.from("users").update({ plan }).eq("id", userId);
        }
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        const { data: subRow } = await supabaseAdmin
          .from("subscriptions")
          .select("user_id")
          .eq("stripe_subscription_id", sub.id)
          .maybeSingle();

        await supabaseAdmin
          .from("subscriptions")
          .update({ status: "cancelled", updated_at: new Date().toISOString() })
          .eq("stripe_subscription_id", sub.id);

        // Was missing: users.plan stayed 'pro' after cancellation since nothing here ever
        // updated it — usage limits kept treating the user as Pro indefinitely.
        if (subRow?.user_id) {
          await supabaseAdmin.from("users").update({ plan: "free" }).eq("id", subRow.user_id);
        } else {
          logger.warn({ subscriptionId: sub.id }, "No matching user_id found for cancelled subscription — users.plan not downgraded");
        }
        break;
      }
      default:
        logger.info({ type: event.type }, "Unhandled Stripe event type");
    }
    return res.json({ received: true });
  } catch (err) {
    logger.error({ err }, "Error processing Stripe webhook");
    return res.status(500).send("Webhook handler error");
  }
});
