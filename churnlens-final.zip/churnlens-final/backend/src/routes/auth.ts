import { Router } from "express";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as GitHubStrategy } from "passport-github2";
import { z } from "zod";
import { env } from "../env.js";
import { supabaseAdmin, supabaseAuth } from "../lib/supabase.js";
import { signToken } from "../middleware/auth.js";
import { authRateLimiter } from "../middleware/rateLimit.js";
import { logger } from "../lib/logger.js";

export const authRouter = Router();

/* ---------------------------- Email / password --------------------------- */

// Password complexity: min 8 chars, at least one letter and one digit — Supabase Auth itself
// only enforces a minimum length, so the stronger rule is applied here before it ever reaches it.
const CredentialsSchema = z.object({
  email: z.string().email(),
  password: z
    .string()
    .min(8, "Пароль должен быть не короче 8 символов")
    .regex(/[a-zA-Zа-яА-Я]/, "Пароль должен содержать хотя бы одну букву")
    .regex(/[0-9]/, "Пароль должен содержать хотя бы одну цифру")
});

authRouter.post("/auth/signup", authRateLimiter, async (req, res) => {
  const parsed = CredentialsSchema.safeParse(req.body);
  if (!parsed.success) {
    const message = parsed.error.errors[0]?.message ?? "Некорректные данные";
    return res.status(400).json({ error: message, details: parsed.error.flatten() });
  }

  const { email, password } = parsed.data;

  // Real Supabase Auth signup — email_confirm:true means the account is immediately usable
  // (no separate email-confirmation flow), matching "автоматически выполнить вход" below.
  const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true
  });

  if (error) {
    const alreadyExists = error.message.toLowerCase().includes("already");
    logger.error({ err: error }, "Supabase Auth signup failed");
    return res
      .status(alreadyExists ? 409 : 500)
      .json({ error: alreadyExists ? "Пользователь с такой почтой уже существует" : "Не удалось создать аккаунт" });
  }

  const user = created.user;
  // Keep our own `users` table row in sync (id shared with Supabase Auth) — other tables
  // (subscriptions, reports) already reference this id via foreign key.
  await supabaseAdmin
    .from("users")
    .upsert({ id: user.id, email: user.email, provider: "email", plan: "free" }, { onConflict: "id" });

  // Auto-login after signup: mint our own app JWT immediately, no separate login round trip.
  const token = signToken(user.id, user.email!);
  return res.status(201).json({ token, user: { id: user.id, email: user.email } });
});

authRouter.post("/auth/login", authRateLimiter, async (req, res) => {
  const parsed = CredentialsSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Некорректные данные" });

  const { email, password } = parsed.data;

  // Real Supabase Auth login. Supabase's own implementation handles timing/enumeration
  // safety for password verification — we don't need our own dummy-hash comparison anymore.
  const { data, error } = await supabaseAuth.auth.signInWithPassword({ email, password });
  if (error || !data.user) {
    return res.status(401).json({ error: "Неверная почта или пароль" });
  }

  const token = signToken(data.user.id, data.user.email!);
  return res.json({ token, user: { id: data.user.id, email: data.user.email } });
});

/* --------------------------------- OAuth --------------------------------- */
// Google and GitHub OAuth apps must be registered by you — the client IDs/secrets
// go in .env. Without them these routes are simply not mounted (see index.ts).

if (env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET) {
  passport.use(
    new GoogleStrategy(
      {
        clientID: env.GOOGLE_CLIENT_ID,
        clientSecret: env.GOOGLE_CLIENT_SECRET,
        callbackURL: env.GOOGLE_CALLBACK_URL!
      },
      async (_accessToken, _refreshToken, profile, done) => {
        try {
          const email = profile.emails?.[0]?.value;
          if (!email) return done(new Error("Google profile has no email"));

          const { data: existing } = await supabaseAdmin.from("users").select("id, email").eq("email", email).maybeSingle();
          if (existing) return done(null, existing);

          const { data: created, error } = await supabaseAdmin
            .from("users")
            .insert({ email, provider: "google", plan: "free" })
            .select("id, email")
            .single();
          if (error) return done(error);
          return done(null, created);
        } catch (err) {
          return done(err as Error);
        }
      }
    )
  );

  authRouter.get("/auth/google", passport.authenticate("google", { scope: ["profile", "email"], session: false }));
  authRouter.get(
    "/auth/google/callback",
    passport.authenticate("google", { session: false, failureRedirect: "/login?error=google" }),
    (req, res) => {
      const user = req.user as { id: string; email: string };
      const token = signToken(user.id, user.email);
      res.redirect(`${env.CLIENT_ORIGIN}/auth/callback?token=${token}`);
    }
  );
}

if (env.GITHUB_CLIENT_ID && env.GITHUB_CLIENT_SECRET) {
  passport.use(
    new GitHubStrategy(
      {
        clientID: env.GITHUB_CLIENT_ID,
        clientSecret: env.GITHUB_CLIENT_SECRET,
        callbackURL: env.GITHUB_CALLBACK_URL!
      },
      async (_accessToken, _refreshToken, profile, done) => {
        try {
          const email = profile.emails?.[0]?.value ?? `${profile.username}@users.noreply.github.com`;
          const { data: existing } = await supabaseAdmin.from("users").select("id, email").eq("email", email).maybeSingle();
          if (existing) return done(null, existing);

          const { data: created, error } = await supabaseAdmin
            .from("users")
            .insert({ email, provider: "github", plan: "free" })
            .select("id, email")
            .single();
          if (error) return done(error);
          return done(null, created);
        } catch (err) {
          return done(err as Error);
        }
      }
    )
  );

  authRouter.get("/auth/github", passport.authenticate("github", { scope: ["user:email"], session: false }));
  authRouter.get(
    "/auth/github/callback",
    passport.authenticate("github", { session: false, failureRedirect: "/login?error=github" }),
    (req, res) => {
      const user = req.user as { id: string; email: string };
      const token = signToken(user.id, user.email);
      res.redirect(`${env.CLIENT_ORIGIN}/auth/callback?token=${token}`);
    }
  );
}
