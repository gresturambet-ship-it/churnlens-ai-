import { Router } from "express";
import { z } from "zod";
import { callClaude, parseClaudeJson } from "../lib/claude.js";
import { supabaseAdmin } from "../lib/supabase.js";
import { logger } from "../lib/logger.js";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.js";
import { analysisRateLimiter } from "../middleware/rateLimit.js";
import { RequestWithId } from "../middleware/requestId.js";
import { handleClaudeRouteError } from "../lib/errorHandler.js";
import { CLAUDE_PRESETS } from "../config.js";
import { sanitizePromptInjection } from "../lib/sanitize.js";
import { checkReplay } from "../lib/replayGuard.js";
import { checkUsageLimit } from "../lib/usageLimit.js";

export const analyzeRouter = Router();

const AnalyzeRequestSchema = z.object({
  text: z
    .string()
    .min(10, "Слишком мало текста для анализа")
    .max(50000)
    .refine((t) => t.split("\n").length <= 10000, "Слишком много строк (макс. 10000)"),
  saveToHistory: z.boolean().default(true),
  customerName: z.string().trim().max(200).optional()
});

const ReasonSchema = z.object({ label: z.string(), percent: z.number().min(0).max(100) });
const PrioritySchema = z.object({ label: z.string(), score: z.number().min(1).max(10) });

const TopRiskSchema = z.object({ label: z.string(), severity: z.number().min(0).max(10), why: z.string().optional() });
const MatrixItemSchema = z.object({ label: z.string(), impact: z.number().min(0).max(10), effort: z.number().min(0).max(10), expectedResult: z.string().optional(), order: z.number().optional() });
const DepartmentSchema = z.object({ name: z.string(), percent: z.number().min(0).max(100) });
const ConfidenceSchema = z.object({ insight: z.string(), score: z.number().min(0).max(100), reason: z.string().optional() });
const EmotionPointSchema = z.object({ label: z.string(), score: z.number().min(-10).max(10) });

const SwotSchema = z.object({
  strengths: z.array(z.string()).max(6),
  weaknesses: z.array(z.string()).max(6),
  opportunities: z.array(z.string()).max(6),
  threats: z.array(z.string()).max(6)
});
const FinancialImpactSchema = z.object({ label: z.string(), impactLevel: z.number().min(0).max(10) });
const ExpectedKpiSchema = z.object({ metric: z.string(), current: z.string().optional(), target: z.string().optional() });

const AnalysisResultSchema = z.object({
  summary: z.string(),
  sentiment: z.enum(["негативная", "смешанная", "нейтральная", "позитивная"]),
  urgency: z.enum(["низкая", "средняя", "высокая", "критическая"]),
  churnForecast: z.string(),
  churnScore: z.number().min(0).max(100),
  churnProbability: z.number().min(0).max(100),
  aiScore: z.number().min(0).max(100),
  riskScore: z.number().min(0).max(100),
  itemsAnalyzed: z.number(),
  reasons: z.array(ReasonSchema).min(1).max(8),
  priorities: z.array(PrioritySchema).min(1).max(8),
  hiddenThemes: z.array(z.string()).max(8),
  todayActions: z.array(z.string()).max(5),
  quickWins: z.array(z.string()).max(6),
  thirtyDayPlan: z.array(z.string()).max(6),
  ninetyDayStrategy: z.array(z.string()).max(6),
  swot: SwotSchema,
  financialImpact: z.array(FinancialImpactSchema).max(8),
  expectedKPIs: z.array(ExpectedKpiSchema).max(6),
  emotionTimeline: z.array(EmotionPointSchema).max(8),
  businessImpact: z.string(),
  topRisks: z.array(TopRiskSchema).max(8),
  priorityMatrix: z.array(MatrixItemSchema).max(8),
  departments: z.array(DepartmentSchema).max(8),
  confidence: z.array(ConfidenceSchema).max(8),
  aiInsights: z.array(z.string()).max(6)
});
export type AnalysisResult = z.infer<typeof AnalysisResultSchema>;

const SYSTEM_PROMPT = `Ты — ведущий retention-аналитик уровня Fortune 500. Тебе дают сырые отзывы, жалобы, тикеты поддержки или причины отмены подписки.
Верни ТОЛЬКО валидный JSON (без markdown, без пояснений вне JSON) строго в этой схеме:
{
  "summary": "1-2 предложения главного вывода",
  "sentiment": "негативная|смешанная|нейтральная|позитивная",
  "urgency": "низкая|средняя|высокая|критическая",
  "churnForecast": "короткая фраза с прогнозом риска оттока",
  "churnScore": число_0_100_общий_риск_оттока,
  "churnProbability": число_0_100_вероятность_потери_клиентов_в_процентах,
  "aiScore": число_0_100_общее_здоровье_отношений_с_клиентами,
  "riskScore": число_0_100_риск_оттока,
  "itemsAnalyzed": число,
  "reasons": [{"label": "причина", "percent": число}],
  "priorities": [{"label": "проблема", "score": число_1_10}],
  "hiddenThemes": ["тема", ...],
  "todayActions": ["что сделать прямо сегодня", ...],
  "quickWins": ["действие на 7 дней", ...],
  "thirtyDayPlan": ["шаг на 30 дней", ...],
  "ninetyDayStrategy": ["шаг на 90 дней", ...],
  "swot": {"strengths": ["..."], "weaknesses": ["..."], "opportunities": ["..."], "threats": ["..."]},
  "financialImpact": [{"label": "проблема", "impactLevel": число_0_10_относительная_серьёзность_НЕ_сумма_в_валюте}, ...],
  "expectedKPIs": [{"metric": "например Retention Rate", "current": "оценка сейчас, если есть в данных", "target": "ожидаемое значение после внедрения рекомендаций"}, ...],
  "emotionTimeline": [{"label": "точка текста", "score": число_минус10_до_10}, ...],
  "businessImpact": "1-2 предложения о влиянии на удержание/выручку, без выдуманных точных сумм",
  "topRisks": [{"label": "риск", "severity": число_0_10, "why": "почему критично"}, ...],
  "priorityMatrix": [{"label": "проблема", "impact": число_0_10, "effort": число_0_10, "expectedResult": "эффект", "order": число}, ...],
  "departments": [{"name": "отдел", "percent": число}, ...],
  "confidence": [{"insight": "вывод", "score": число_0_100, "reason": "почему такая уверенность"}, ...],
  "aiInsights": ["неожиданная закономерность", ...]
}
Проценты и оценки должны быть основаны на реальной частоте и серьёзности тем в исходном тексте, не выдумывай данные, которых нет в тексте. Для financialImpact НИКОГДА не указывай конкретные суммы денег — только относительную оценку серьёзности 0-10, так как точных финансовых данных у тебя нет.`;

analyzeRouter.post("/analyze", requireAuth, analysisRateLimiter, async (req: AuthenticatedRequest, res) => {
  const parseResult = AnalyzeRequestSchema.safeParse(req.body);
  if (!parseResult.success) {
    return res.status(400).json({ error: "Некорректный запрос", details: parseResult.error.flatten() });
  }

  const { saveToHistory, customerName } = parseResult.data;
  const text = sanitizePromptInjection(parseResult.data.text);
  const userId = req.user!.id;
  const requestId = (req as RequestWithId).requestId;

  if (!checkReplay(userId, text)) {
    return res.status(409).json({ error: "Этот же запрос уже обрабатывается или был обработан только что." });
  }

  const usage = await checkUsageLimit(userId, "analyze");
  if (!usage.allowed) {
    return res.status(429).json({
      error: `Лимит тарифа исчерпан: ${usage.used}/${usage.limit} анализов в этом месяце (тариф ${usage.plan}).`,
      plan: usage.plan,
      used: usage.used,
      limit: usage.limit
    });
  }

  try {
    const raw = await callClaude({
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: text }],
      ...CLAUDE_PRESETS.analyze,
      requestId
    });

    const parsedJson = parseClaudeJson<unknown>(raw);
    const validated = AnalysisResultSchema.safeParse(parsedJson);
    if (!validated.success) {
      logger.error({ err: validated.error.flatten() }, "Claude output failed schema validation");
      return res.status(502).json({ error: "AI вернул данные в неожиданном формате. Попробуйте ещё раз." });
    }

    const result = validated.data;

    // Track usage for billing / plan limits
    await supabaseAdmin.from("api_usage").insert({
      user_id: userId,
      endpoint: "analyze",
      tokens_estimate: text.length,
      created_at: new Date().toISOString()
    });

    let reportId: string | null = null;
    if (saveToHistory) {
      const { data, error } = await supabaseAdmin
        .from("reports")
        .insert({
          user_id: userId,
          summary: result.summary,
          sentiment: result.sentiment,
          urgency: result.urgency,
          churn_forecast: result.churnForecast,
          payload: result,
          raw_input_excerpt: text.slice(0, 2000),
          customer_name: customerName || null,
          created_at: new Date().toISOString()
        })
        .select("id")
        .single();

      if (error) logger.error({ err: error }, "Failed to persist report");
      else reportId = data.id;
    }

    return res.json({ reportId, result, usage: { plan: usage.plan, used: usage.used + 1, limit: usage.limit } });
  } catch (err) {
    handleClaudeRouteError(err, res, "/analyze");
  }
});

// Streaming variant: same validation/sanitization/auth as /analyze, but relays Claude's
// response to the client as SSE while it's generated, then sends one final "result" event
// with the parsed+validated JSON. The API key still never leaves this server.
analyzeRouter.post("/analyze/stream", requireAuth, analysisRateLimiter, async (req: AuthenticatedRequest, res) => {
  const parseResult = AnalyzeRequestSchema.safeParse(req.body);
  if (!parseResult.success) {
    return res.status(400).json({ error: "Некорректный запрос", details: parseResult.error.flatten() });
  }
  const text = sanitizePromptInjection(parseResult.data.text);
  const userId = req.user!.id;
  if (!checkReplay(userId, text)) {
    return res.status(409).json({ error: "Этот же запрос уже обрабатывается." });
  }

  const usage = await checkUsageLimit(userId, "analyze");
  if (!usage.allowed) {
    return res.status(429).json({
      error: `Лимит тарифа исчерпан: ${usage.used}/${usage.limit} анализов в этом месяце (тариф ${usage.plan}).`,
      plan: usage.plan,
      used: usage.used,
      limit: usage.limit
    });
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  try {
    const raw = await callClaude({
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: text }],
      ...CLAUDE_PRESETS.analyze,
      requestId: (req as RequestWithId).requestId
    });
    // Emit the full text as one delta — true token-level SSE requires Anthropic's own
    // stream:true mode; wire that in here if/when you need incremental deltas instead of
    // one chunk, following the same event shape.
    res.write(`data: ${JSON.stringify({ type: "delta", text: raw })}\n\n`);

    const parsedJson = parseClaudeJson<unknown>(raw);
    const validated = AnalysisResultSchema.safeParse(parsedJson);
    if (!validated.success) {
      res.write(`data: ${JSON.stringify({ type: "error", error: "AI вернул данные в неожиданном формате." })}\n\n`);
      return res.end();
    }
    let reportId: string | null = null;
    if (parseResult.data.saveToHistory) {
      const { data } = await supabaseAdmin
        .from("reports")
        .insert({ user_id: userId, summary: validated.data.summary, payload: validated.data, customer_name: parseResult.data.customerName || null, created_at: new Date().toISOString() })
        .select("id")
        .single();
      reportId = data?.id ?? null;
    }

    // Was missing here — without this, checkUsageLimit()'s count never increased for
    // stream-based analyses, so the monthly limit was effectively unenforced on this route.
    await supabaseAdmin.from("api_usage").insert({
      user_id: userId,
      endpoint: "analyze",
      tokens_estimate: text.length,
      created_at: new Date().toISOString()
    });

    res.write(`data: ${JSON.stringify({ type: "result", result: { ...validated.data, reportId }, usage: { plan: usage.plan, used: usage.used + 1, limit: usage.limit } })}\n\n`);
    res.end();
  } catch (err) {
    logger.error({ err }, "Error in /analyze/stream");
    res.write(`data: ${JSON.stringify({ type: "error", error: "AI-сервис временно недоступен." })}\n\n`);
    res.end();
  }
});
