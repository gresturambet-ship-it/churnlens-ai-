import rateLimit from "express-rate-limit";
import { env } from "../env.js";
import type { AuthenticatedRequest } from "./auth.js";

// Keys by authenticated user id when available, falls back to IP for anonymous requests.
export const analysisRateLimiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => (req as AuthenticatedRequest).user?.id ?? req.ip ?? "anonymous",
  message: { error: "Слишком много запросов. Попробуйте через минуту." }
});

export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Слишком много попыток входа. Попробуйте позже." }
});
