import { randomUUID } from "node:crypto";
import { Request, Response, NextFunction } from "express";
import { logger, logRequestOutcome } from "../lib/logger.js";

export interface RequestWithId extends Request {
  requestId: string;
}

// Assigns a UUID to every request for log correlation. Deliberately NOT sent back as a
// response header — the requirement is that it's visible only in logs, not to the client.
export function requestIdMiddleware(req: Request, res: Response, next: NextFunction) {
  const withId = req as RequestWithId;
  withId.requestId = randomUUID();
  const start = process.hrtime.bigint();

  res.on("finish", () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1_000_000;
    logRequestOutcome({
      requestId: withId.requestId,
      route: `${req.method} ${req.route?.path ?? req.path}`,
      durationMs: Math.round(durationMs),
      outcome: res.statusCode >= 400 ? "error" : "success"
    });
  });

  next();
}

// Pass this alongside a Claude call's own log lines so the request and the upstream
// call it triggered share one correlation id in the logs.
export function childLoggerFor(requestId: string) {
  return logger.child({ requestId });
}
