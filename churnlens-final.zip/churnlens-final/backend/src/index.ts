import express from "express";
import helmet from "helmet";
import cors from "cors";
import passport from "passport";
import rateLimit from "express-rate-limit";
import { requestIdMiddleware } from "./middleware/requestId.js";
import { env } from "./env.js";
import { logger } from "./lib/logger.js";
import { analyzeRouter } from "./routes/analyze.js";
import { chatRouter } from "./routes/chat.js";
import { reportsRouter } from "./routes/reports.js";
import { authRouter } from "./routes/auth.js";
import { stripeRouter } from "./routes/stripe.js";
import { compareRouter } from "./routes/compare.js";
import { customersRouter } from "./routes/customers.js";

const app = express();

// SECURITY-CRITICAL: this value must exactly match the number of trusted reverse proxies
// actually in front of this app (Railway/Render/Fly typically add exactly one hop). If you
// deploy this WITHOUT a proxy in front (direct exposure) and leave this set to 1, an
// attacker can spoof the X-Forwarded-For header themselves and Express will trust it as
// req.ip — completely defeating every IP-based rate limiter in this file. Set to 0 (or
// remove this line) if there is no reverse proxy; verify against your actual deployment.
app.set("trust proxy", 1);
app.disable("x-powered-by"); // don't advertise the framework/version to attackers

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        connectSrc: ["'self'", "https://api.anthropic.com", "https://api.stripe.com"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        objectSrc: ["'none'"],
        baseUri: ["'none'"],
        frameAncestors: ["'none'"] // clickjacking protection — this IS a real HTTP header, unlike the frontend's <meta> CSP
      }
    },
    hsts: { maxAge: 63072000, includeSubDomains: true, preload: true }, // Strict-Transport-Security
    frameguard: { action: "deny" }, // X-Frame-Options: DENY (belt-and-suspenders with frame-ancestors above)
    noSniff: true, // X-Content-Type-Options: nosniff
    referrerPolicy: { policy: "strict-origin-when-cross-origin" },
    crossOriginEmbedderPolicy: true, // COEP
    crossOriginOpenerPolicy: { policy: "same-origin" }, // COOP
    crossOriginResourcePolicy: { policy: "same-origin" } // CORP
  })
);

// Permissions-Policy isn't covered by helmet's defaults — set it explicitly, deny by default.
app.use((_req, res, next) => {
  res.setHeader(
    "Permissions-Policy",
    "geolocation=(), camera=(), microphone=(), payment=(self), usb=(), interest-cohort=()"
  );
  next();
});

// Every response from this API can carry per-user private data — explicitly forbid any
// intermediary (CDN, corporate proxy, browser bfcache) from storing it, regardless of
// what caching defaults something in front of this app might have.
app.use((_req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

// No cookies are used anywhere in this API (auth is a Bearer JWT the client stores and
// attaches per-request) — so CSRF, which relies on the browser auto-sending cookies, does
// not apply here by design. credentials:false and a single explicit origin keep CORS tight.
app.use(
  cors({
    origin: env.CLIENT_ORIGIN,
    credentials: false,
    methods: ["GET", "POST", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"]
  })
);

// Global request-rate ceiling in front of everything, in addition to the tighter
// per-route limiters in middleware/rateLimit.ts — a baseline defense against bulk/bot traffic.
app.use(
  rateLimit({
    windowMs: 60_000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Слишком много запросов." }
  })
);

app.use(requestIdMiddleware);
app.use(passport.initialize());

// Stripe webhook needs the raw body for signature verification — mount BEFORE express.json().
// Path must match where the route actually lives: stripeRouter is mounted at /api below,
// so the real path is /api/billing/webhook, not /billing/webhook.
app.use("/api/billing/webhook", express.raw({ type: "application/json" }));

// JSON parsing for every other route, including stripeRouter's /billing/checkout — must run
// BEFORE stripeRouter is mounted (routers see only middleware registered earlier), but must
// skip the webhook path since its raw body was already consumed above.
app.use((req, res, next) => {
  if (req.path === "/api/billing/webhook") return next();
  express.json({ limit: "1mb" })(req, res, next);
});

app.use("/api", stripeRouter);

app.get("/health", (_req, res) => res.json({ status: "ok", uptime: process.uptime() }));

app.use("/api", authRouter);
app.use("/api", analyzeRouter);
app.use("/api", chatRouter);
app.use("/api", reportsRouter);
app.use("/api", compareRouter);
app.use("/api", customersRouter);

// 404 — generic, doesn't confirm/deny which routes exist beyond what's already public knowledge
app.use((_req, res) => res.status(404).json({ error: "Не найдено" }));

// Centralized error handler — never leak stack traces, upstream error bodies, or internal
// structure to the client, even outside try/catch blocks in individual routes.
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  logger.error({ err }, "Unhandled error");
  res.status(500).json({
    error: "Внутренняя ошибка сервера",
    ...(env.NODE_ENV !== "production" ? { detail: err.message } : {})
  });
});

app.listen(env.PORT, () => {
  logger.info(`ChurnLens backend listening on port ${env.PORT} (${env.NODE_ENV})`);
});
