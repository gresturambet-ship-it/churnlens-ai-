import pino from "pino";
import { env } from "../env.js";

export const logger = pino({
  level: env.NODE_ENV === "production" ? "info" : "debug",
  transport:
    env.NODE_ENV === "production"
      ? undefined
      : { target: "pino-pretty", options: { colorize: true } },
  // Belt-and-suspenders: even if a future code change accidentally passes one of these
  // fields into a log call, pino will redact it before it's written anywhere.
  redact: {
    paths: [
      "email",
      "*.email",
      "text",
      "*.text",
      "rawInput",
      "*.rawInput",
      "password",
      "*.password",
      "password_hash",
      "*.password_hash",
      "token",
      "*.token",
      "authorization",
      "*.authorization",
      "req.headers.authorization",
      "req.headers.cookie",
      "cookie",
      "*.cookie",
      "apiKey",
      "*.apiKey",
      "ANTHROPIC_API_KEY"
    ],
    censor: "[redacted]"
  }
});

// Enforces the "safe logging" contract for request-level log lines: only timestamp
// (added automatically by pino), request id, duration, and outcome — never request/response
// bodies, headers, or any user content. Use this instead of logger.info directly for
// routine request logging; use the raw `logger` for genuine error diagnostics, which still
// benefit from the redaction above.
export function logRequestOutcome(params: {
  requestId: string;
  route: string;
  durationMs: number;
  outcome: "success" | "error";
}) {
  logger.info(params, "request completed");
}
