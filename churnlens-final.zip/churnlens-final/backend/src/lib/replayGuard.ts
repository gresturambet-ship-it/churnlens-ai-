import { createHash } from "node:crypto";
import { REPLAY_WINDOW_MS } from "../config.js";

/**
 * Blocks an identical request (same user + same text) from running again within a short
 * window — protects against replayed/duplicated requests (accidental double-submits,
 * or a captured request replayed by a script).
 *
 * LIMITATION: this cache is in-process memory. It works correctly for a single server
 * instance. If you deploy this behind a load balancer with multiple instances, or on
 * serverless (where each invocation may be a fresh process), this guard won't see
 * requests handled by a different instance — replace with a shared store (Redis,
 * `SET key value NX EX <ttl>`) for that deployment shape.
 */
const seen = new Map<string, number>();

// Periodic cleanup so this map never grows unbounded — a real memory-leak guard, not just
// a correctness detail. Runs independently of any single request.
setInterval(() => {
  const now = Date.now();
  for (const [key, timestamp] of seen) {
    if (now - timestamp > REPLAY_WINDOW_MS) seen.delete(key);
  }
}, REPLAY_WINDOW_MS).unref();

export function checkReplay(userId: string, text: string): boolean {
  const hash = createHash("sha256").update(text).digest("hex");
  const key = `${userId}:${hash}`;
  const now = Date.now();
  const last = seen.get(key);

  if (last !== undefined && now - last < REPLAY_WINDOW_MS) {
    return false; // reject — this exact request was just seen
  }
  seen.set(key, now);
  return true;
}
