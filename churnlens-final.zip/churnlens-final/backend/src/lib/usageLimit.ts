import { supabaseAdmin } from "./supabase.js";
import { logger } from "./logger.js";

// Per-endpoint monthly limits by plan. 'analyze' numbers are unchanged from before —
// only chat/compare are new. business/enterprise mirror pro, same pattern already used
// for analyze.
export const PLAN_LIMITS: Record<string, Record<string, number>> = {
  analyze: { free: 3, pro: 100, business: 100, enterprise: 100 },
  chat: { free: 20, pro: 500, business: 500, enterprise: 500 },
  compare: { free: 3, pro: 50, business: 50, enterprise: 50 }
};

export interface UsageStatus {
  allowed: boolean;
  plan: string;
  used: number;
  limit: number;
}

function startOfMonthIso(): string {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString();
}

// Thrown when the usage check itself can't be trusted (DB read failed) — callers should
// treat this as "cannot verify quota, do not proceed" and respond 503, not run the AI call.
export class UsageCheckError extends Error {
  constructor(message: string, public cause?: unknown) {
    super(message);
    this.name = "UsageCheckError";
  }
}

/**
 * Server-side monthly quota for a given endpoint ('analyze' | 'chat' | 'compare'). Plan
 * comes from the users table, usage count comes from the existing api_usage table — same
 * mechanism as before, just parameterized by endpoint instead of hardcoded to 'analyze'.
 * Nothing here is client-suppliable: every value is re-read from the DB on every check, so
 * repeating requests cannot inflate or reset the count.
 *
 * Fail-CLOSED: if either DB read fails, this throws UsageCheckError instead of silently
 * treating the user as having 0 usage (which would let the AI call proceed unlimited during
 * a DB outage). Callers must catch this and respond 503 without calling the AI.
 */
export async function checkUsageLimit(userId: string, endpoint: string): Promise<UsageStatus> {
  const { data: userRow, error: userError } = await supabaseAdmin
    .from("users")
    .select("plan")
    .eq("id", userId)
    .maybeSingle();
  if (userError) {
    logger.error({ err: userError }, "Failed to read user plan — failing closed");
    throw new UsageCheckError("Не удалось проверить тариф пользователя", userError);
  }
  const plan = userRow?.plan || "free";
  const limits = PLAN_LIMITS[endpoint] || PLAN_LIMITS.analyze;
  const limit = limits[plan] ?? limits.free;

  const { count, error: countError } = await supabaseAdmin
    .from("api_usage")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("endpoint", endpoint)
    .gte("created_at", startOfMonthIso());
  if (countError) {
    logger.error({ err: countError }, "Failed to count usage — failing closed");
    throw new UsageCheckError("Не удалось проверить лимит использования", countError);
  }

  const used = count ?? 0;
  return { allowed: used < limit, plan, used, limit };
}
