import { createClient } from "@supabase/supabase-js";
import { env } from "../env.js";

// Service-role client: full DB access, used ONLY on the server, never sent to the client.
export const supabaseAdmin = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false }
});

// Anon-key client used specifically for Supabase Auth calls (signInWithPassword) — Supabase's
// own auth endpoints expect the anon key, not the service role key, even when called server-side.
export const supabaseAuth = createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY, {
  auth: { autoRefreshToken: false, persistSession: false }
});
