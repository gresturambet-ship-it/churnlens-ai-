// Prompt-injection defense-in-depth. This is a heuristic filter over the most common
// instruction-override patterns — the primary defense is still that SYSTEM_PROMPT in each
// route explicitly frames the user's text as *data to analyze*, never as instructions.
// This exists to catch the blunt, obvious attempts before they even reach the model.
const PROMPT_INJECTION_PATTERNS: RegExp[] = [
  /ignore (all )?(previous|prior|above) instructions?/gi,
  /disregard (all )?(previous|prior|above) instructions?/gi,
  /system prompt/gi,
  /developer message/gi,
  /\btool[_ ]call\b/gi,
  /\brole\s*:\s*system\b/gi,
  /\bassistant\s*:\s*/gi,
  /^\s*A:\s*/gim
];

export function sanitizePromptInjection(text: string): string {
  let cleaned = text;
  for (const pattern of PROMPT_INJECTION_PATTERNS) {
    cleaned = cleaned.replace(pattern, "[отфильтровано]");
  }
  return cleaned;
}
