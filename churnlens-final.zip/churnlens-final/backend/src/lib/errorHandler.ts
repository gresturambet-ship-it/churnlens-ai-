import { Response } from "express";
import { ClaudeError } from "./claude.js";
import { logger } from "./logger.js";

/**
 * Handles an error caught in a Claude-calling route the same way everywhere: log full
 * details server-side, send only a safe generic message to the client. Was previously
 * copy-pasted with minor variations in analyze.ts, chat.ts, and compare.ts.
 */
export function handleClaudeRouteError(err: unknown, res: Response, routeName: string): void {
  if (err instanceof ClaudeError) {
    logger.error({ err }, `Claude error in ${routeName}`);
    if (err.status === 429) {
      res.status(429).json({ error: "Слишком много запросов к AI. Попробуйте через минуту." });
      return;
    }
    res.status(502).json({ error: "AI-сервис временно недоступен. Попробуйте позже." });
    return;
  }
  logger.error({ err }, `Unexpected error in ${routeName}`);
  res.status(500).json({ error: "Внутренняя ошибка сервера" });
}
