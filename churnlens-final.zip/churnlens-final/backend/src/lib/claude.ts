import { env } from "../env.js";
import { logger } from "./logger.js";

export class ClaudeError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = "ClaudeError";
  }
}

interface ClaudeMessage {
  role: "user" | "assistant";
  content: string;
}

interface CallClaudeOptions {
  system: string;
  messages: ClaudeMessage[];
  maxTokens?: number;
  timeoutMs?: number;
  retries?: number;
  requestId?: string; // correlation id: ties this Claude call's log lines to the originating request
}

/**
 * Calls the Anthropic Messages API server-side. The API key never leaves the server.
 * Retries transient failures with exponential backoff, and enforces a hard timeout.
 */
export async function callClaude({
  system,
  messages,
  maxTokens = 1200,
  timeoutMs = 30000,
  retries = 2,
  requestId
}: CallClaudeOptions): Promise<string> {
  let lastError: unknown;
  const log = requestId ? logger.child({ requestId }) : logger;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: env.CLAUDE_MODEL,
          max_tokens: maxTokens,
          system,
          messages
        }),
        signal: controller.signal
      });

      clearTimeout(timer);

      if (res.status === 429) {
        throw new ClaudeError("Claude API rate limited the server", 429);
      }
      if (!res.ok) {
        // Don't log the response body verbatim — it can echo back fragments of the request
        // in some error cases. Log only the status; full diagnosis happens by reproducing
        // against the Anthropic API directly if needed.
        throw new ClaudeError(`Claude API error ${res.status}`, res.status);
      }

      const data = (await res.json()) as { content: { type: string; text?: string }[] };
      const text = data.content
        .map((b) => (b.type === "text" ? b.text ?? "" : ""))
        .join("\n")
        .trim();

      if (!text) throw new ClaudeError("Empty response from Claude");
      return text;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
      log.warn({ attempt }, "Claude call failed, will retry if attempts remain");
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 500 * 2 ** attempt));
      }
    }
  }

  log.error("Claude call failed after all retries");
  throw lastError instanceof ClaudeError
    ? lastError
    : new ClaudeError("Claude API unreachable after retries");
}

// Prototype Pollution guard: strip __proto__ / constructor / prototype keys from any
// object built out of Claude's JSON response before anything else touches it. Zod's
// .parse() already only extracts known fields (so it wouldn't inherit a polluted
// prototype either), but this runs first so even code paths that inspect the raw
// parsed object before validation can't be affected.
const DANGEROUS_KEYS = new Set(["__proto__", "constructor", "prototype"]);
const MAX_JSON_DEPTH = 50; // guards against a maliciously deep-nested JSON bomb causing a stack overflow
function stripPrototypePollution(value: unknown, depth = 0): unknown {
  if (depth > MAX_JSON_DEPTH) return null;
  if (Array.isArray(value)) return value.map((v) => stripPrototypePollution(v, depth + 1));
  if (value && typeof value === "object") {
    const clean: Record<string, unknown> = {};
    for (const key of Object.keys(value)) {
      if (DANGEROUS_KEYS.has(key)) continue;
      clean[key] = stripPrototypePollution((value as Record<string, unknown>)[key], depth + 1);
    }
    return clean;
  }
  return value;
}

/** Strips markdown fences, parses JSON, and removes prototype-pollution vectors. */
export function parseClaudeJson<T>(raw: string): T {
  const cleaned = raw.replace(/```json|```/g, "").trim();
  try {
    return stripPrototypePollution(JSON.parse(cleaned)) as T;
  } catch {
    throw new ClaudeError("Claude returned malformed JSON");
  }
}
