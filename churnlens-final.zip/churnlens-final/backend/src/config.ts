// Single source of truth for tunable constants that were previously duplicated as magic
// numbers across analyze.ts / chat.ts / compare.ts / replayGuard.ts.

export const CLAUDE_PRESETS = {
  analyze: { maxTokens: 1400, timeoutMs: 30000, retries: 2 },
  chat: { maxTokens: 700, timeoutMs: 20000, retries: 1 },
  compare: { maxTokens: 700, timeoutMs: 20000, retries: 1 }
} as const;

export const REPLAY_WINDOW_MS = 5000;

export const TEXT_LIMITS = {
  maxChars: 50000,
  maxLines: 10000
} as const;
