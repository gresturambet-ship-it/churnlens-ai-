-- ChurnLens AI — Supabase schema
-- Run this in the Supabase SQL editor (Project → SQL Editor → New query).

create extension if not exists "uuid-ossp";

-- ============================================================= users
create table if not exists users (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  password_hash text,                -- null for OAuth-only accounts
  provider text not null default 'email' check (provider in ('email','google','github')),
  plan text not null default 'free' check (plan in ('free','pro','business','enterprise')),
  created_at timestamptz not null default now()
);

-- ============================================================= reports
create table if not exists reports (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  summary text not null,
  sentiment text not null,
  urgency text not null,
  churn_forecast text not null,
  payload jsonb not null,            -- full structured analysis (reasons, priorities, insights...)
  raw_input_excerpt text,            -- first ~2000 chars of the source text, for AI chat context
  customer_name text,                -- optional, user-supplied at analyze time — powers Customer 360 grouping
  created_at timestamptz not null default now()
);
create index if not exists idx_reports_user_created on reports(user_id, created_at desc);
create index if not exists idx_reports_user_customer on reports(user_id, customer_name);
-- Existing databases: ALTER TABLE reports ADD COLUMN IF NOT EXISTS customer_name text;
--                      CREATE INDEX IF NOT EXISTS idx_reports_user_customer ON reports(user_id, customer_name);

-- ============================================================= history
-- Lightweight event log, separate from full reports (e.g. chat questions asked,
-- exports performed, comparisons viewed) — useful for the dashboard's activity feed.
create table if not exists history (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  report_id uuid references reports(id) on delete set null,
  action text not null,               -- 'analyzed' | 'exported_pdf' | 'exported_csv' | 'chat_question' | ...
  detail jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_history_user_created on history(user_id, created_at desc);

-- ============================================================= subscription
create table if not exists subscriptions (
  user_id uuid primary key references users(id) on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan text not null default 'free' check (plan in ('free','pro','business','enterprise')),
  status text not null default 'inactive' check (status in ('active','inactive','cancelled','past_due')),
  updated_at timestamptz not null default now()
);

-- ============================================================= api_usage
create table if not exists api_usage (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  endpoint text not null,
  tokens_estimate int,
  created_at timestamptz not null default now()
);
create index if not exists idx_api_usage_user_created on api_usage(user_id, created_at desc);

-- ============================================================= Row Level Security
-- The backend uses the service-role key (bypasses RLS) for all writes above.
-- These policies protect the tables if you ever expose them via Supabase client-side
-- queries (e.g. using the anon key with a user's own JWT) instead of only through
-- your Express API.

alter table users enable row level security;
alter table reports enable row level security;
alter table history enable row level security;
alter table subscriptions enable row level security;
alter table api_usage enable row level security;

create policy "users read own row" on users
  for select using (auth.uid() = id);

create policy "reports owned by user" on reports
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "history owned by user" on history
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "subscription owned by user" on subscriptions
  for select using (auth.uid() = user_id);

create policy "api_usage owned by user" on api_usage
  for select using (auth.uid() = user_id);
