# Security headers for deploying the ChurnLens AI frontend

The frontend artifact (`churnlens-v2.html`) sets what it can via `<meta>` tags — but
`<meta>` cannot set most HTTP security headers. Whatever serves this file as a static
site (Netlify, Vercel, Cloudflare Pages, Nginx, etc.) must set these at the HTTP level.

## Netlify — `_headers` file (place at project root)

```
/*
  Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), camera=(), microphone=(), payment=(self), usb=(), interest-cohort=()
  Cross-Origin-Embedder-Policy: require-corp
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Resource-Policy: same-origin
  Content-Security-Policy: default-src 'self'; script-src 'self' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self' https://your-backend-domain.com; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'
```

## Vercel — `vercel.json`

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Strict-Transport-Security", "value": "max-age=63072000; includeSubDomains; preload" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" },
        { "key": "Permissions-Policy", "value": "geolocation=(), camera=(), microphone=(), payment=(self), usb=(), interest-cohort=()" },
        { "key": "Cross-Origin-Embedder-Policy", "value": "require-corp" },
        { "key": "Cross-Origin-Opener-Policy", "value": "same-origin" },
        { "key": "Cross-Origin-Resource-Policy", "value": "same-origin" },
        { "key": "Content-Security-Policy", "value": "default-src 'self'; script-src 'self' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self' https://your-backend-domain.com; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'" }
      ]
    }
  ]
}
```

## Nginx

```nginx
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Permissions-Policy "geolocation=(), camera=(), microphone=(), payment=(self), usb=(), interest-cohort=()" always;
add_header Cross-Origin-Embedder-Policy "require-corp" always;
add_header Cross-Origin-Opener-Policy "same-origin" always;
add_header Cross-Origin-Resource-Policy "same-origin" always;
add_header Content-Security-Policy "default-src 'self'; script-src 'self' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self' https://your-backend-domain.com; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'" always;
```

## Why `script-src` here has no `'unsafe-inline'`

This config assumes you've moved the artifact's inline `<script>` block into an external
`.js` file (recommended for real production — see the note in `churnlens-v2.html`'s
`<head>`). If you deploy the file as-is with logic still inline, you'll need to add
`'unsafe-inline'` back to `script-src`, which weakens this considerably. Splitting the
script out is a ~10-minute change and worth doing before this goes live for real users.

## Before you deploy

- Replace `https://your-backend-domain.com` in `connect-src` with your actual deployed
  backend URL (see `/churnlens-backend`) — the artifact's direct `fetch` to
  `api.anthropic.com` only works inside Claude.ai's own preview sandbox; a real deployment
  must call your backend's `/api/analyze` instead, never Anthropic directly from the browser.
- Run `npm audit` in the backend project — dependency versions here were written without
  network access to verify against current CVE databases.
